
class ClassificationModel(object):

    def __init__(self):
        pass

    def fit(self, X_train, y_train, X_val, y_val):
        pass
            
    def predict(self, X, full_sequence=True):
        pass